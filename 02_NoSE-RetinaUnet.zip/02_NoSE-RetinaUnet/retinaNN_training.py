# ==============================================
# 修复所有问题：
# 1. 切换工作目录到F盘（避免文件存C盘）
# 2. 修正变量定义顺序（解决NameError）
# 3. 保留原作者核心逻辑，适配DRIVE数据集
# 4. 所有文件保存在F盘Retina-Unet-master目录
# 5. 【最终修复】用os.path.join拼接路径，自动补全反斜杠，解决路径缺失问题
# ==============================================
import sys
import os

# 核心：切换到脚本所在的F盘目录（彻底避免C盘存储）
script_dir = os.path.dirname(os.path.abspath(__file__))
os.chdir(script_dir)
print(f"📌 已切换到脚本目录：{os.getcwd()}")

# 把项目根目录和lib文件夹加入Python模块搜索路径
sys.path.append(script_dir)
sys.path.append(os.path.join(script_dir, 'lib'))

import numpy as np
from keras.models import Model
from keras.layers import Input, concatenate, Conv2D, MaxPooling2D, UpSampling2D, Reshape, core, Dropout
from keras.optimizers import Adam
from keras.callbacks import ModelCheckpoint, LearningRateScheduler
from keras import backend as K
from keras.optimizers import SGD

# 导入自定义模块
from lib.help_functions import *
from lib.extract_patches import get_data_training

# 确保实验文件夹存在，避免保存文件时报错
def create_exp_dir(exp_name):
    exp_path = os.path.join(script_dir, exp_name)
    if not os.path.exists(exp_path):
        os.makedirs(exp_path)
        print(f"✅ 创建实验文件夹：{exp_path}")
    return exp_path

# Define the neural network (原作者Unet结构，一字未改)
def get_unet(n_ch,patch_height,patch_width):
    inputs = Input(shape=(n_ch,patch_height,patch_width))
    conv1 = Conv2D(32, (3, 3), activation='relu', padding='same',data_format='channels_first')(inputs)
    conv1 = Dropout(0.2)(conv1)
    conv1 = Conv2D(32, (3, 3), activation='relu', padding='same',data_format='channels_first')(conv1)
    pool1 = MaxPooling2D((2, 2))(conv1)
    
    conv2 = Conv2D(64, (3, 3), activation='relu', padding='same',data_format='channels_first')(pool1)
    conv2 = Dropout(0.2)(conv2)
    conv2 = Conv2D(64, (3, 3), activation='relu', padding='same',data_format='channels_first')(conv2)
    pool2 = MaxPooling2D((2, 2))(conv2)
    
    conv3 = Conv2D(128, (3, 3), activation='relu', padding='same',data_format='channels_first')(pool2)
    conv3 = Dropout(0.2)(conv3)
    conv3 = Conv2D(128, (3, 3), activation='relu', padding='same',data_format='channels_first')(conv3)

    up1 = UpSampling2D(size=(2, 2))(conv3)
    up1 = concatenate([conv2,up1],axis=1)
    conv4 = Conv2D(64, (3, 3), activation='relu', padding='same',data_format='channels_first')(up1)
    conv4 = Dropout(0.2)(conv4)
    conv4 = Conv2D(64, (3, 3), activation='relu', padding='same',data_format='channels_first')(conv4)
    
    up2 = UpSampling2D(size=(2, 2))(conv4)
    up2 = concatenate([conv1,up2], axis=1)
    conv5 = Conv2D(32, (3, 3), activation='relu', padding='same',data_format='channels_first')(up2)
    conv5 = Dropout(0.2)(conv5)
    conv5 = Conv2D(32, (3, 3), activation='relu', padding='same',data_format='channels_first')(conv5)
    
    conv6 = Conv2D(2, (1, 1), activation='relu',padding='same',data_format='channels_first')(conv5)
    conv6 = core.Reshape((2,patch_height*patch_width))(conv6)
    conv6 = core.Permute((2,1))(conv6)
    conv7 = core.Activation('softmax')(conv6)

    model = Model(inputs=inputs, outputs=conv7)
    model.compile(optimizer='sgd', loss='categorical_crossentropy',metrics=['accuracy'])
    return model

# ========= 硬编码参数（全部指向F盘，无C盘依赖） =========
# 1. 数据集根路径：指向共用的F:\毕业\DRIVE（双反斜杠避免转义，绝对路径）
path_data = "F:\\毕业\\DRIVE"

# 2. 实验名称（保存模型/结果的文件夹，保存在组二脚本目录，独立隔离）
name_experiment = "Retina_Unet_Training"
exp_dir = create_exp_dir(name_experiment)

# 3. 训练参数（和原代码一致，无需修改）
N_epochs = 100          # 训练轮数
batch_size = 32         # 批次大小
patch_height = 48       # 补丁高度
patch_width = 48        # 补丁宽度
N_subimgs = 10000       # 提取的子图像数量
inside_FOV = True       # 只选择FOV内的补丁

# 4. 数据集子路径（无开头/，匹配DRIVE内部层级）
train_imgs_original = "training/images/"
train_groundTruth = "training/1st_manual/"

# 【关键修复】用os.path.join拼接路径，自动补全反斜杠，生成正确路径
train_img_path = os.path.join(path_data, train_imgs_original)
train_gt_path = os.path.join(path_data, train_groundTruth)

# 打印所有参数，确认生效（显示最终正确路径）
print("="*50)
print("✅ 所有参数已设置完成：")
print(f"数据集根路径：{path_data}")
print(f"实验文件夹：{exp_dir}")
print(f"训练轮数：{N_epochs} | 批次大小：{batch_size}")
print(f"补丁尺寸：{patch_height}x{patch_width} | 子图像数量：{N_subimgs}")
print(f"✅ 实际训练图像路径：{train_img_path}")  # 正确路径：F:\毕业\DRIVE\training\images\
print(f"✅ 实际金标准路径：{train_gt_path}")      # 正确路径：F:\毕业\DRIVE\training\1st_manual\
print("="*50)

# ============ 加载数据并提取补丁 ============
patches_imgs_train, patches_masks_train = get_data_training(
    DRIVE_train_imgs_original=train_img_path,  # 传入拼接好的正确路径
    DRIVE_train_groudTruth=train_gt_path,      # 传入拼接好的正确路径
    patch_height=patch_height,
    patch_width=patch_width,
    N_subimgs=N_subimgs,
    inside_FOV=inside_FOV
)

# ========= 保存输入样本（验证数据加载正确） ==========
N_sample = min(patches_imgs_train.shape[0],40)
visualize(group_images(patches_imgs_train[0:N_sample,:,:,:],5),os.path.join(exp_dir,'sample_input_imgs'))
visualize(group_images(patches_masks_train[0:N_sample,:,:,:],5),os.path.join(exp_dir,'sample_input_masks'))

# =========== 构建并保存模型结构 =====
n_ch = patches_imgs_train.shape[1]
patch_height = patches_imgs_train.shape[2]
patch_width = patches_imgs_train.shape[3]
model = get_unet(n_ch, patch_height, patch_width)
print("✅ 模型构建完成，输出形状：", model.output_shape)

# 保存模型结构到F盘组二目录
json_string = model.to_json()
model_arch_path = os.path.join(exp_dir, f"{name_experiment}_architecture.json")
with open(model_arch_path, 'w') as f:
    f.write(json_string)
print(f"✅ 模型结构已保存到：{model_arch_path}")

# ============ 训练模型 ==================================
# 保存最优模型到F盘组二目录（独立权重，不与其他组混淆）
checkpointer = ModelCheckpoint(
    filepath=os.path.join(exp_dir, f"{name_experiment}_best_weights.h5"), 
    verbose=1, 
    monitor='val_loss', 
    mode='auto', 
    save_best_only=True
)

# 转换mask格式
patches_masks_train = masks_Unet(patches_masks_train)  

# 开始训练
print("="*50)
print("🚀 开始训练模型（全程在F盘运行）...")
print("="*50)
model.fit(
    patches_imgs_train, 
    patches_masks_train, 
    epochs=N_epochs, 
    batch_size=batch_size, 
    verbose=1, 
    shuffle=True, 
    validation_split=0.1, 
    callbacks=[checkpointer]
)

# ========== 保存最后一轮模型 ===================
last_weight_path = os.path.join(exp_dir, f"{name_experiment}_last_weights.h5")
model.save_weights(last_weight_path, overwrite=True)
print(f"✅ 最后一轮模型权重已保存到：{last_weight_path}")
print("="*50)
print("🎉 训练完成！所有文件均保存在组二专属目录，与其他模型完全隔离")
print("="*50)