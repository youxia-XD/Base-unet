###################################################
# 最终修复版：F盘全路径 + 修正导入错误 + 无冗余依赖
##################################################
import numpy as np
import os
import sys
from matplotlib import pyplot as plt
from keras.models import model_from_json

# ========== 核心：强制所有操作在F盘 ==========
# 获取脚本所在的F盘根目录（Retina-Unet-master）
script_dir = os.path.dirname(os.path.abspath(__file__))
os.chdir(script_dir)  # 切换到F盘脚本目录
sys.path.append(script_dir)  # 添加根目录到搜索路径
sys.path.append(os.path.join(script_dir, 'lib'))  # 添加lib目录到搜索路径
print(f"📌 已切换到F盘脚本目录：{script_dir}")

# 修复导入：删掉不存在的save_hdf5，只导入用到的函数
from lib.help_functions import load_hdf5, visualize, group_images, pred_to_imgs
from lib.extract_patches import recompone, recompone_overlap, paint_border, kill_border, pred_only_FOV, get_data_testing, get_data_testing_overlap
from lib.pre_processing import my_PreProc

# ========== 硬编码参数（全F盘路径，和训练一致） ==========
# 1. 数据集根路径（F盘DRIVE文件夹）
path_data = os.path.join(script_dir, "DRIVE")
# 2. 实验文件夹（F盘，训练结果保存的位置）
name_experiment = "Retina_Unet_Training"
path_experiment = os.path.join(script_dir, name_experiment)
# 3. 补丁尺寸（和训练一致）
patch_height = 48
patch_width = 48
# 4. 重叠预测参数
stride_height = 10
stride_width = 10
# 5. 测试集参数
Imgs_to_test = 20  # DRIVE测试集共20张
N_visual = 5       # 每组可视化5张
average_mode = True  # 重叠预测更精准
best_last = "best"   # 使用最优权重

# ========== 加载测试集原始数据（F盘） ==========
# 测试集原始图像
DRIVE_test_imgs_original = os.path.join(path_data, "test", "images")
test_imgs_orig = load_hdf5(DRIVE_test_imgs_original)
full_img_height = test_imgs_orig.shape[2]
full_img_width = test_imgs_orig.shape[3]

# 测试集边界掩码（DRIVE的mask在test/mask目录）
DRIVE_test_border_masks = os.path.join(path_data, "test", "mask")
test_border_masks = load_hdf5(DRIVE_test_border_masks)

# ========== 提取测试集补丁 ==========
patches_imgs_test = None
new_height = None
new_width = None
masks_test = None
patches_masks_test = None

if average_mode == True:
    patches_imgs_test, new_height, new_width, masks_test = get_data_testing_overlap(
        DRIVE_test_imgs_original=DRIVE_test_imgs_original,
        DRIVE_test_groudTruth=os.path.join(path_data, "test", "1st_manual"),
        Imgs_to_test=Imgs_to_test,
        patch_height=patch_height,
        patch_width=patch_width,
        stride_height=stride_height,
        stride_width=stride_width
    )
else:
    patches_imgs_test, patches_masks_test = get_data_testing(
        DRIVE_test_imgs_original=DRIVE_test_imgs_original,
        DRIVE_test_groudTruth=os.path.join(path_data, "test", "1st_manual"),
        Imgs_to_test=Imgs_to_test,
        patch_height=patch_height,
        patch_width=patch_width,
    )

# ========== 加载训练好的模型（F盘） ==========
# 模型结构路径（F盘）
model_json_path = os.path.join(path_experiment, f"{name_experiment}_architecture.json")
# 最优权重路径（F盘）
model_weight_path = os.path.join(path_experiment, f"{name_experiment}_{best_last}_weights.h5")

# 加载模型
with open(model_json_path, 'r') as f:
    model = model_from_json(f.read())
model.load_weights(model_weight_path)
print(f"✅ 成功加载F盘模型：{model_weight_path}")

# 预测测试补丁
predictions = model.predict(patches_imgs_test, batch_size=32, verbose=2)
print("✅ 预测完成，预测结果尺寸：", predictions.shape)

# ========== 转换预测结果为图像格式 ==========
pred_patches = pred_to_imgs(predictions, patch_height, patch_width, "original")

# ========== 拼接补丁为完整图像 ==========
pred_imgs = None
orig_imgs = None
gtruth_masks = None

if average_mode == True:
    pred_imgs = recompone_overlap(pred_patches, new_height, new_width, stride_height, stride_width)
    orig_imgs = my_PreProc(test_imgs_orig[0:pred_imgs.shape[0], :, :, :])
    gtruth_masks = masks_test
else:
    pred_imgs = recompone(pred_patches, 13, 12)
    orig_imgs = recompone(patches_imgs_test, 13, 12)
    gtruth_masks = recompone(patches_masks_test, 13, 12)

# ========== 过滤FOV外区域 ==========
kill_border(pred_imgs, test_border_masks)
# 还原原始尺寸
orig_imgs = orig_imgs[:, :, 0:full_img_height, 0:full_img_width]
pred_imgs = pred_imgs[:, :, 0:full_img_height, 0:full_img_width]
gtruth_masks = gtruth_masks[:, :, 0:full_img_height, 0:full_img_width]

print("📊 最终图像尺寸：")
print("原始图：", orig_imgs.shape)
print("预测图：", pred_imgs.shape)
print("真实标注：", gtruth_masks.shape)

# ========== 保存可视化结果（全在F盘） ==========
visualize(group_images(orig_imgs, N_visual), os.path.join(path_experiment, "all_originals"))
visualize(group_images(pred_imgs, N_visual), os.path.join(path_experiment, "all_predictions"))
visualize(group_images(gtruth_masks, N_visual), os.path.join(path_experiment, "all_groundTruths"))

# 保存原图+标注+预测对比图
assert orig_imgs.shape[0] == pred_imgs.shape[0] == gtruth_masks.shape[0]
N_predicted = orig_imgs.shape[0]
for i in range(int(N_predicted / N_visual)):
    orig_stripe = group_images(orig_imgs[i*N_visual:(i+1)*N_visual, :, :, :], N_visual)
    masks_stripe = group_images(gtruth_masks[i*N_visual:(i+1)*N_visual, :, :, :], N_visual)
    pred_stripe = group_images(pred_imgs[i*N_visual:(i+1)*N_visual, :, :, :], N_visual)
    total_img = np.concatenate((orig_stripe, masks_stripe, pred_stripe), axis=0)
    save_path = os.path.join(path_experiment, f"{name_experiment}_Original_GroundTruth_Prediction{i}.png")
    visualize(total_img, save_path)

# ========== 计算评估指标 ==========
print("\n\n=======================  评估模型效果 =======================")
# 仅计算FOV内结果
y_scores, y_true = pred_only_FOV(pred_imgs, gtruth_masks, test_border_masks)
print(f"FOV内有效像素数：预测={y_scores.shape[0]} | 真实={y_true.shape[0]}")

# 1. ROC曲线 + AUC
from sklearn.metrics import roc_curve, roc_auc_score
fpr, tpr, thresholds = roc_curve(y_true, y_scores)
AUC_ROC = roc_auc_score(y_true, y_scores)
print(f"\n📈 ROC曲线下面积（AUC）：{AUC_ROC:.4f}")
plt.figure()
plt.plot(fpr, tpr, '-', label=f'AUC = {AUC_ROC:.4f}')
plt.title('ROC Curve')
plt.xlabel("False Positive Rate (FPR)")
plt.ylabel("True Positive Rate (TPR)")
plt.legend(loc="lower right")
plt.savefig(os.path.join(path_experiment, "ROC.png"))
plt.close()

# 2. Precision-Recall曲线 + AUC
from sklearn.metrics import precision_recall_curve, confusion_matrix, f1_score, jaccard_similarity_score
precision, recall, thresholds = precision_recall_curve(y_true, y_scores)
precision = np.fliplr([precision])[0]
recall = np.fliplr([recall])[0]
AUC_prec_rec = np.trapz(precision, recall)
print(f"🎯 精确率-召回率AUC：{AUC_prec_rec:.4f}")
plt.figure()
plt.plot(recall, precision, '-', label=f'AUC = {AUC_prec_rec:.4f}')
plt.title('Precision-Recall Curve')
plt.xlabel("Recall")
plt.ylabel("Precision")
plt.legend(loc="lower right")
plt.savefig(os.path.join(path_experiment, "Precision_recall.png"))
plt.close()

# 3. 混淆矩阵 + 基础指标
threshold_confusion = 0.37
y_pred = np.where(y_scores >= threshold_confusion, 1, 0)
confusion = confusion_matrix(y_true, y_pred)
accuracy = (confusion[0,0] + confusion[1,1]) / np.sum(confusion) if np.sum(confusion) != 0 else 0
specificity = confusion[0,0] / (confusion[0,0] + confusion[0,1]) if (confusion[0,0] + confusion[0,1]) != 0 else 0
sensitivity = confusion[1,1] / (confusion[1,1] + confusion[1,0]) if (confusion[1,1] + confusion[1,0]) != 0 else 0
precision = confusion[1,1] / (confusion[1,1] + confusion[0,1]) if (confusion[1,1] + confusion[0,1]) != 0 else 0

print(f"\n🔍 混淆矩阵（阈值={threshold_confusion}）：")
print(confusion)
print(f"全局准确率：{accuracy:.4f}")
print(f"特异度：{specificity:.4f}")
print(f"灵敏度：{sensitivity:.4f}")
print(f"精确率：{precision:.4f}")

# 4. Jaccard系数 + F1分数
intersection = confusion[1,1]  # 真阳性（正确识别的血管像素）
union = confusion[1,1] + confusion[1,0] + confusion[0,1]  # 血管像素+预测为血管的非血管像素
jaccard_index = intersection / union if union != 0 else 0
F1_score = f1_score(y_true, y_pred, average='binary')
print(f"\n🤝 Jaccard相似系数：{jaccard_index:.4f}")
print(f"🏆 F1分数：{F1_score:.4f}")

# ========== 保存评估结果（F盘） ==========
perf_path = os.path.join(path_experiment, "performances.txt")
with open(perf_path, 'w', encoding='utf-8') as f:
    f.write(f"Area under the ROC curve: {AUC_ROC:.4f}\n")
    f.write(f"Area under Precision-Recall curve: {AUC_prec_rec:.4f}\n")
    f.write(f"Jaccard similarity score: {jaccard_index:.4f}\n")
    f.write(f"F1 score: {F1_score:.4f}\n\n")
    f.write(f"Confusion matrix:\n{confusion}\n")
    f.write(f"ACCURACY: {accuracy:.4f}\n")
    f.write(f"SENSITIVITY: {sensitivity:.4f}\n")
    f.write(f"SPECIFICITY: {specificity:.4f}\n")
    f.write(f"PRECISION: {precision:.4f}\n")

print(f"\n✅ 所有结果已保存到F盘：{path_experiment}")
print("🎉 测试集预测+评估完成！无任何文件写入C盘。")