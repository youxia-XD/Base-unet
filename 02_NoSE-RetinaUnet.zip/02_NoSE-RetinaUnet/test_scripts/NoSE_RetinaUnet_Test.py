import numpy as np
import os
from PIL import Image
# 纯Keras导入（对接PyTorch后端，无任何TensorFlow依赖）
from keras.models import Model
from keras.layers import Input, Conv2D, MaxPooling2D, UpSampling2D, Dropout, concatenate, core
from keras.optimizers import SGD

# ===================== 毕设平台适配：PyTorch+Keras | 配置无需修改 =====================
MODEL_NAME = "NoSE-RetinaUnet"
# 你的实际权重路径（双反斜杠避免转义）
WEIGHT_PATH = "F:\\毕业\\02_NoSE-RetinaUnet\\Retina_Unet_Training\\Retina_Unet_Training_best_weights.h5"
DRIVE_ROOT = "F:\\毕业\\DRIVE"
# 测试集共用文件路径
TEST_IMG_PATH = os.path.join(DRIVE_ROOT, "patches_imgs_test.npy")
TEST_GT_PATH = os.path.join(DRIVE_ROOT, "patches_masks_test.npy")
TEST_FOV_PATH = os.path.join(DRIVE_ROOT, "patches_fov_test.npy")
TEST_SHAPE_PATH = os.path.join(DRIVE_ROOT, "test_img_shapes.npy")
# 结果保存目录（自动创建）
SAVE_ROOT = os.path.join("F:\\毕业\\02_NoSE-RetinaUnet", "test_results")
os.makedirs(SAVE_ROOT, exist_ok=True)
SAVE_PRED_IMG = os.path.join(SAVE_ROOT, f"{MODEL_NAME}_pred_masks.npy")
SAVE_METRICS = os.path.join(SAVE_ROOT, f"{MODEL_NAME}_test_metrics.txt")
# 核心参数：3通道输入（与训练完全匹配，毕设训练时的设置）
N_CH, PATCH_H, PATCH_W = 3, 48, 48
PATCH_SIZE = 48
STRIDE = 24
THRESHOLD = 0.5  # 二值化阈值

# ===================== 1. 构建模型（PyTorch+Keras适配，3通道+层名匹配）=====================
def build_original_unet(n_ch, patch_height, patch_width):
    # 输入形状：(48,48,3) 3通道+channels_last（Keras通用格式，适配PyTorch后端）
    inputs = Input(shape=(patch_height, patch_width, n_ch))
    # 编码器：显式命名层，确保与训练权重层名一一对应（按层加载关键）
    conv1 = Conv2D(32, (3,3), activation='relu', padding='same', name='conv1_1')(inputs)
    conv1 = Dropout(0.2)(conv1)
    conv1 = Conv2D(32, (3,3), activation='relu', padding='same', name='conv1_2')(conv1)
    pool1 = MaxPooling2D((2,2), name='pool1')(conv1)

    conv2 = Conv2D(64, (3,3), activation='relu', padding='same', name='conv2_1')(pool1)
    conv2 = Dropout(0.2)(conv2)
    conv2 = Conv2D(64, (3,3), activation='relu', padding='same', name='conv2_2')(conv2)
    pool2 = MaxPooling2D((2,2), name='pool2')(conv2)

    conv3 = Conv2D(128, (3,3), activation='relu', padding='same', name='conv3_1')(pool2)
    conv3 = Dropout(0.2)(conv3)
    conv3 = Conv2D(128, (3,3), activation='relu', padding='same', name='conv3_2')(conv3)

    # 解码器：按通道拼接（axis=-1，Keras通用）
    up1 = UpSampling2D((2,2), name='up1')(conv3)
    up1 = concatenate([conv2, up1], axis=-1, name='concat1')
    conv4 = Conv2D(64, (3,3), activation='relu', padding='same', name='conv4_1')(up1)
    conv4 = Dropout(0.2)(conv4)
    conv4 = Conv2D(64, (3,3), activation='relu', padding='same', name='conv4_2')(conv4)

    up2 = UpSampling2D((2,2), name='up2')(conv4)
    up2 = concatenate([conv1, up2], axis=-1, name='concat2')
    conv5 = Conv2D(32, (3,3), activation='relu', padding='same', name='conv5_1')(up2)
    conv5 = Dropout(0.2)(conv5)
    conv5 = Conv2D(32, (3,3), activation='relu', padding='same', name='conv5_2')(conv5)

    # 输出层：与训练完全一致，适配二分类
    conv6 = Conv2D(2, (1,1), activation='relu', padding='same', name='conv6')(conv5)
    conv6 = core.Reshape((patch_height*patch_width, 2), name='reshape')(conv6)
    output = core.Activation('softmax', name='softmax')(conv6)

    # 优化器与训练一致（SGD），适配PyTorch后端编译
    model = Model(inputs=inputs, outputs=output)
    model.compile(optimizer=SGD(), loss='categorical_crossentropy', metrics=['accuracy'])
    return model

# ===================== 2. 量化指标计算（FOV内，毕设实验核心指标）=====================
def calculate_metrics(pred, gt, fov):
    # 仅保留FOV有效区域（DRIVE数据集要求，排除背景干扰）
    pred = pred[fov == 1]
    gt = gt[fov == 1]
    # 计算混淆矩阵（TP/TN/FP/FN）
    tp = np.sum((pred == 1) & (gt == 1))  # 真阳性（血管预测正确）
    tn = np.sum((pred == 0) & (gt == 0))  # 真阴性（背景预测正确）
    fp = np.sum((pred == 1) & (gt == 0))  # 假阳性（背景误判血管）
    fn = np.sum((pred == 0) & (gt == 1))  # 假阴性（血管误判背景）
    # 计算核心指标（加1e-8避免除零，毕设绘图/表格直接用）
    accuracy = (tp + tn) / (tp + tn + fp + fn + 1e-8)
    dsc = 2 * tp / (2 * tp + fp + fn + 1e-8)  # 医学分割核心指标（骰子系数）
    iou = tp / (tp + fp + fn + 1e-8)         # 交并比
    sensitivity = tp / (tp + fn + 1e-8)      # 灵敏度（细血管分割能力）
    specificity = tn / (tn + fp + 1e-8)      # 特异度（背景分割能力）
    return {
        "Accuracy": round(accuracy, 4), "DSC": round(dsc, 4), "IOU": round(iou, 4),
        "Sensitivity": round(sensitivity, 4), "Specificity": round(specificity, 4),
        "TP": tp, "TN": tn, "FP": fp, "FN": fn
    }

# ===================== 3. 补丁拼接还原（毕设通用，还原原始测试图尺寸）=====================
def patches2img(patches, img_shapes, patch_size=48, stride=24):
    imgs = []
    idx = 0
    for h, w in img_shapes:
        img = np.zeros((h, w), dtype=np.float32)
        count = np.zeros((h, w), dtype=np.float32)
        # 滑动窗口反向拼接，处理重叠补丁（消除拼接痕迹）
        for i in range(0, h - patch_size + 1, stride):
            for j in range(0, w - patch_size + 1, stride):
                img[i:i+patch_size, j:j+patch_size] += patches[idx]
                count[i:i+patch_size, j:j+patch_size] += 1
                idx += 1
        # 重叠区域取平均，保证像素值正常
        img = img / (count + 1e-8)
        imgs.append(img)
    return np.array(imgs)

# ===================== 4. 核心测试推理（PyTorch+Keras纯原生，无TF）=====================
def test_model():
    print(f"🚀 开始{MODEL_NAME}测试集推理（PyTorch+Keras适配版）...")
    print(f"📌 权重路径：{WEIGHT_PATH}")
    print(f"📌 测试补丁总数：{np.load(TEST_IMG_PATH).shape[0]}")

    # 步骤1：加载预处理测试数据（1通道灰度图）
    test_imgs = np.load(TEST_IMG_PATH)  # 形状：(N,48,48)
    test_gt = np.load(TEST_GT_PATH)
    test_fov = np.load(TEST_FOV_PATH)
    test_shapes = np.load(TEST_SHAPE_PATH)

    # 步骤2：关键！1通道扩展为3通道（与训练完全匹配，不影响灰度图推理）
    test_imgs = np.expand_dims(test_imgs, axis=-1)  # (N,48,48,1)
    test_imgs = np.repeat(test_imgs, 3, axis=-1)   # (N,48,48,3) 复制3次为3通道
    print(f"✅ 输入通道扩展完成：{test_imgs.shape}（3通道，与训练一致）")

    # 步骤3：构建模型+按层名加载权重（PyTorch后端友好，无错位）
    model = build_original_unet(N_CH, PATCH_H, PATCH_W)
    if os.path.exists(WEIGHT_PATH):
        model.load_weights(WEIGHT_PATH, by_name=True)  # 按层名加载，彻底避免权重错位
        print("✅ 权重按层名加载成功！开始推理...")
    else:
        raise FileNotFoundError(f"权重文件不存在！请检查路径：{WEIGHT_PATH}")

    # 步骤4：模型推理（PyTorch后端加速，无维度冲突）
    pred_probs = model.predict(test_imgs, batch_size=32, verbose=1)
    # 提取血管类概率（第2列），还原为48×48补丁
    pred_vessel = pred_probs[:, :, 1].reshape(-1, PATCH_SIZE, PATCH_SIZE)
    # 概率二值化（>0.5判定为血管，毕设通用阈值）
    pred_binary = (pred_vessel > THRESHOLD).astype(np.float32)

    # 步骤5：补丁拼接还原为原始测试图尺寸（584×565）
    pred_imgs = patches2img(pred_binary, test_shapes, PATCH_SIZE, STRIDE)
    gt_imgs = patches2img(test_gt, test_shapes, PATCH_SIZE, STRIDE)
    fov_imgs = patches2img(test_fov, test_shapes, PATCH_SIZE, STRIDE)
    # 保存预测结果（供毕设可视化/绘图使用）
    np.save(SAVE_PRED_IMG, pred_imgs)
    print(f"✅ 预测结果保存：{SAVE_PRED_IMG}，形状：{pred_imgs.shape}（20张测试图）")

    # 步骤6：计算20张测试图逐图指标（毕设实验数据基础）
    all_metrics = []
    for i in range(len(pred_imgs)):
        single_metric = calculate_metrics(pred_imgs[i], gt_imgs[i], fov_imgs[i])
        all_metrics.append(single_metric)
        print(f"📊 测试图{i+1} | 核心DSC：{single_metric['DSC']} | IOU：{single_metric['IOU']}")

    # 步骤7：计算平均指标（毕设论文核心数据，直接复制到表格）
    avg_metrics = {
        "Average_Accuracy": round(np.mean([m['Accuracy'] for m in all_metrics]), 4),
        "Average_DSC": round(np.mean([m['DSC'] for m in all_metrics]), 4),
        "Average_IOU": round(np.mean([m['IOU'] for m in all_metrics]), 4),
        "Average_Sensitivity": round(np.mean([m['Sensitivity'] for m in all_metrics]), 4),
        "Average_Specificity": round(np.mean([m['Specificity'] for m in all_metrics]), 4)
    }

    # 步骤8：保存指标到文件（毕设实验记录，可直接读取）
    with open(SAVE_METRICS, "w", encoding="utf-8") as f:
        f.write(f"{MODEL_NAME} - DRIVE测试集量化指标（PyTorch+Keras | FOV内 | 20张平均）\n")
        f.write("="*70 + "\n")
        for metric_name, value in avg_metrics.items():
            f.write(f"{metric_name}: {value}\n")
        f.write("="*70 + "\n\n")
        f.write("【毕设专用：单张测试图详细指标】\n")
        for idx, m in enumerate(all_metrics):
            f.write(f"测试图{idx+1}: {str(m)}\n")

    # 打印最终核心结果（毕设快速查看）
    print("="*70)
    print(f"🎉 {MODEL_NAME} 测试推理完全完成（PyTorch+Keras原生）！")
    print(f"📊 毕设核心平均指标（FOV有效区域）：")
    print(f"   📈 平均DSC（医学分割核心）：{avg_metrics['Average_DSC']}")
    print(f"   📈 平均IOU：{avg_metrics['Average_IOU']}")
    print(f"   📈 平均灵敏度（细血管分割）：{avg_metrics['Average_Sensitivity']}")
    print(f"   📈 平均特异度（背景分割）：{avg_metrics['Average_Specificity']}")
    print(f"💾 所有指标已保存至：{SAVE_METRICS}")
    print("="*70)

# 主函数执行（PyTorch+Keras环境直接运行）
if __name__ == "__main__":
    test_model()