import numpy as np
from PIL import Image
import cv2

from lib.help_functions import *

#My pre processing (use for both training and testing!)
def my_PreProc(data):
    # ========== 核心：适配5维输入 (N,1,H,W,3) → 标准4维(N,C,H,W) ==========
    print(f"🔍 原始输入维度：{data.shape} | 维度数：{len(data.shape)}")
    
    # 步骤1：处理5维输入 (N,1,H,W,3) → 4维(N,3,H,W)
    if len(data.shape) == 5:
        # 去掉多余的1维度 → (N,H,W,3)，再转置成(N,3,H,W)
        data = np.squeeze(data, axis=1)  # (N,H,W,3)
        data = np.transpose(data, (0,3,1,2))  # (N,3,H,W) → 标准RGB格式
    
    # 步骤2：处理4维输入（如果是(N,3,H,W)直接用，(N,1,H,W)也兼容）
    assert len(data.shape) == 4, f"输入维度错误，期望4维(N,C,H,W)，实际{len(data.shape)}维"
    assert data.shape[1] == 3 or data.shape[1] == 1, f"通道数错误，期望3(RGB)或1(灰度)，实际{data.shape[1]}通道"
    
    # ========== 原作者的核心逻辑（完美适配RGB图） ==========
    # 1. RGB图（DRIVE实际是RGB）：执行原作者的rgb2gray
    if data.shape[1] == 3:
        train_imgs = rgb2gray(data)  # 转成(N,1,H,W)
    # 2. 灰度图：直接使用
    elif data.shape[1] == 1:
        train_imgs = data
    
    # 保留原作者所有预处理步骤
    train_imgs = dataset_normalized(train_imgs)
    train_imgs = clahe_equalized(train_imgs)
    train_imgs = adjust_gamma(train_imgs, 1.2)
    train_imgs = train_imgs/255.  #reduce to 0-1 range
    return train_imgs

#==== histogram equalization（原作者代码，一字未改）
def histo_equalized(imgs):
    assert (len(imgs.shape)==4)  #4D arrays
    assert (imgs.shape[1]==1)  #check the channel is 1
    imgs_equalized = np.empty(imgs.shape)
    for i in range(imgs.shape[0]):
        imgs_equalized[i,0] = cv2.equalizeHist(np.array(imgs[i,0], dtype = np.uint8))
    return imgs_equalized

# CLAHE（原作者代码，一字未改）
def clahe_equalized(imgs):
    assert (len(imgs.shape)==4)  #4D arrays
    assert (imgs.shape[1]==1)  #check the channel is 1
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
    imgs_equalized = np.empty(imgs.shape)
    for i in range(imgs.shape[0]):
        imgs_equalized[i,0] = clahe.apply(np.array(imgs[i,0], dtype = np.uint8))
    return imgs_equalized

# dataset_normalized（原作者代码，一字未改）
def dataset_normalized(imgs):
    assert (len(imgs.shape)==4)  #4D arrays
    assert (imgs.shape[1]==1)  #check the channel is 1
    imgs_normalized = np.empty(imgs.shape)
    imgs_std = np.std(imgs)
    imgs_mean = np.mean(imgs)
    imgs_normalized = (imgs-imgs_mean)/imgs_std
    for i in range(imgs.shape[0]):
        imgs_normalized[i] = ((imgs_normalized[i] - np.min(imgs_normalized[i])) / (np.max(imgs_normalized[i])-np.min(imgs_normalized[i])))*255
    return imgs_normalized

# adjust_gamma（原作者代码，一字未改）
def adjust_gamma(imgs, gamma=1.0):
    assert (len(imgs.shape)==4)  #4D arrays
    assert (imgs.shape[1]==1)  #check the channel is 1
    invGamma = 1.0 / gamma
    table = np.array([((i / 255.0) ** invGamma) * 255 for i in np.arange(0, 256)]).astype("uint8")
    new_imgs = np.empty(imgs.shape)
    for i in range(imgs.shape[0]):
        new_imgs[i,0] = cv2.LUT(np.array(imgs[i,0], dtype = np.uint8), table)
    return new_imgs