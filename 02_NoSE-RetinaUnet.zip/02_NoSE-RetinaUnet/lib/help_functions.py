import h5py
import numpy as np
from PIL import Image
from matplotlib import pyplot as plt
import os  # 新增：用于判断路径/文件类型
def load_hdf5(infile):
    # 新增逻辑：如果是文件夹，读取里面的tif/gif图像；如果是图像文件，直接读取；否则读h5文件
    if os.path.isdir(infile):
        # 读取文件夹下的所有图像（优先tif，其次gif）
        img_paths = []
        # 先找tif文件（训练图像）
        for f in os.listdir(infile):
            if f.endswith('.tif'):
                img_paths.append(os.path.join(infile, f))
        # 如果没有tif，找gif文件（标注）
        if len(img_paths) == 0:
            for f in os.listdir(infile):
                if f.endswith('.gif'):
                    img_paths.append(os.path.join(infile, f))
        # 按文件名排序（保证图像和标注对应）
        img_paths.sort()
        # 读取所有图像
        imgs = []
        for path in img_paths:
            if path.endswith('.gif'):
                # 标注图是灰度图，转L模式
                img = Image.open(path).convert('L')
            else:
                # 训练图像直接读取
                img = Image.open(path)
            # 转numpy数组，保持原始维度 (H,W)
            img_np = np.array(img, dtype=np.float32)
            imgs.append(img_np)
        # 转换为4维数组：(N,1,H,W) （仅扩展一次维度！）
        imgs_np = np.array(imgs)  # (N,H,W)
        imgs_np = np.expand_dims(imgs_np, axis=1)  # (N,1,H,W) → 仅这一次扩展！
        return imgs_np
    elif os.path.isfile(infile):
        # 如果是文件，先判断是否是h5文件，否则读图像
        if infile.endswith('.h5') or infile.endswith('.hdf5'):
            # 原有逻辑：读h5文件
            with h5py.File(infile,"r") as f:
                return f["image"][()]
        else:
            # 读单张图像（tif/gif）
            if infile.endswith('.gif'):
                img = Image.open(infile).convert('L')
            else:
                img = Image.open(infile)
            img_np = np.array(img, dtype=np.float32)  # (H,W)
            # 转换为4维数组：(1,1,H,W) （仅扩展一次维度！）
            img_np = np.expand_dims(img_np, axis=0)  # (1,H,W)
            img_np = np.expand_dims(img_np, axis=1)  # (1,1,H,W) → 仅这一次扩展！
            return img_np
    else:
        raise FileNotFoundError(f"路径不存在：{infile}")
        
def write_hdf5(arr,outfile):
  with h5py.File(outfile,"w") as f:
    f.create_dataset("image", data=arr, dtype=arr.dtype)

#convert RGB image in black and white
def rgb2gray(rgb):
    assert (len(rgb.shape)==4)  #4D arrays
    assert (rgb.shape[1]==3)
    bn_imgs = rgb[:,0,:,:]*0.299 + rgb[:,1,:,:]*0.587 + rgb[:,2,:,:]*0.114
    bn_imgs = np.reshape(bn_imgs,(rgb.shape[0],1,rgb.shape[2],rgb.shape[3]))
    return bn_imgs

#group a set of images row per columns
def group_images(data,per_row):
    assert data.shape[0]%per_row==0
    assert (data.shape[1]==1 or data.shape[1]==3)
    data = np.transpose(data,(0,2,3,1))  #corect format for imshow
    all_stripe = []
    for i in range(int(data.shape[0]/per_row)):
        stripe = data[i*per_row]
        for k in range(i*per_row+1, i*per_row+per_row):
            stripe = np.concatenate((stripe,data[k]),axis=1)
        all_stripe.append(stripe)
    totimg = all_stripe[0]
    for i in range(1,len(all_stripe)):
        totimg = np.concatenate((totimg,all_stripe[i]),axis=0)
    return totimg

#visualize image (as PIL image, NOT as matplotlib!)
def visualize(data,filename):
    assert (len(data.shape)==3) #height*width*channels
    img = None
    if data.shape[2]==1:  #in case it is black and white
        data = np.reshape(data,(data.shape[0],data.shape[1]))
    if np.max(data)>1:
        img = Image.fromarray(data.astype(np.uint8))   #the image is already 0-255
    else:
        img = Image.fromarray((data*255).astype(np.uint8))  #the image is between 0-1
    img.save(filename + '.png')
    return img

#prepare the mask in the right shape for the Unet
def masks_Unet(masks):
    assert (len(masks.shape)==4)  #4D arrays
    assert (masks.shape[1]==1 )  #check the channel is 1
    im_h = masks.shape[2]
    im_w = masks.shape[3]
    masks = np.reshape(masks,(masks.shape[0],im_h*im_w))
    new_masks = np.empty((masks.shape[0],im_h*im_w,2))
    for i in range(masks.shape[0]):
        for j in range(im_h*im_w):
            if  masks[i,j] == 0:
                new_masks[i,j,0]=1
                new_masks[i,j,1]=0
            else:
                new_masks[i,j,0]=0
                new_masks[i,j,1]=1
    return new_masks

def pred_to_imgs(pred, patch_height, patch_width, mode="original"):
    assert (len(pred.shape)==3)  #3D array: (Npatches,height*width,2)
    assert (pred.shape[2]==2 )  #check the classes are 2
    pred_images = np.empty((pred.shape[0],pred.shape[1]))  #(Npatches,height*width)
    if mode=="original":
        for i in range(pred.shape[0]):
            for pix in range(pred.shape[1]):
                pred_images[i,pix]=pred[i,pix,1]
    elif mode=="threshold":
        for i in range(pred.shape[0]):
            for pix in range(pred.shape[1]):
                if pred[i,pix,1]>=0.5:
                    pred_images[i,pix]=1
                else:
                    pred_images[i,pix]=0
    else:
        print("mode " +str(mode) +" not recognized, it can be 'original' or 'threshold'")
        exit()
    pred_images = np.reshape(pred_images,(pred_images.shape[0],1, patch_height, patch_width))
    return pred_images