import numpy as np
import os
from PIL import Image

# ===================== 配置（无需修改，适配你的目录）=====================
DRIVE_ROOT = "F:\\毕业\\DRIVE"  # 原始DRIVE数据集根路径
TRAIN_IMG_PATH = os.path.join(DRIVE_ROOT, "training", "images")  # 训练图像路径
TRAIN_MASK_PATH = os.path.join(DRIVE_ROOT, "training", "1st_manual")  # 标注路径
PATCH_SIZE = 48  # 补丁尺寸，和模型一致（48×48）
STRIDE = 24  # 裁剪步长（24，补丁重叠，提升训练效果）
IMG_EXT = ".tif"  # 训练图像格式
MASK_EXT = ".gif"  # 标注格式
# 生成的补丁保存路径（直接保存到F:\毕业\DRIVE）
SAVE_IMG_PATCH = os.path.join(DRIVE_ROOT, "patches_imgs_train.npy")
SAVE_MASK_PATCH = os.path.join(DRIVE_ROOT, "patches_masks_train.npy")

# ===================== 工具函数：读取图像和标注（修正后，兼容TIF/GIF） =====================
def read_train_img(img_path):
    """读取DRIVE训练图像（*.tif），PIL读取+转灰度+归一化，增加有效性检查"""
    try:
        # 用PIL读取TIF图像，转灰度模式（L模式）
        img = Image.open(img_path).convert('L')
        img = np.array(img, dtype=np.float32)
        # 归一化到0-1（符合模型训练数据要求）
        img = img / 255.0
        # 检查图像是否有效（非空、尺寸正确）
        if img is None or img.size == 0:
            raise ValueError("图像读取后为空")
        return img
    except Exception as e:
        raise FileNotFoundError(f"读取图像失败：{img_path}，错误原因：{str(e)}")

def read_train_mask(mask_path):
    """读取DRIVE标注（*.gif），转为二值图（0=背景，1=血管），增加有效性检查"""
    try:
        mask = Image.open(mask_path).convert('L')
        mask = np.array(mask, dtype=np.float32)
        # 标注中255代表血管，转为1；0为背景，保持不变
        mask[mask == 255] = 1
        # 归一化到0-1，和图像数据范围一致
        mask = mask / 1.0
        # 检查标注是否有效
        if mask is None or mask.size == 0:
            raise ValueError("标注读取后为空")
        return mask
    except Exception as e:
        raise FileNotFoundError(f"读取标注失败：{mask_path}，错误原因：{str(e)}")

# ===================== 核心：裁剪48×48补丁（原有逻辑不变，增加匹配检查） =====================
def crop_patches():
    print(f"🔍 开始从DRIVE原始数据裁剪{PATCH_SIZE}×{PATCH_SIZE}补丁...")
    print(f"📂 原始图像路径：{TRAIN_IMG_PATH}")
    print(f"📂 原始标注路径：{TRAIN_MASK_PATH}")
    
    img_patches = []  # 存储图像补丁
    mask_patches = []  # 存储标注补丁
    
    # 获取所有训练图像文件名（按数字序号排序，匹配DRIVE命名规则）
    img_files = [f for f in os.listdir(TRAIN_IMG_PATH) if f.endswith(IMG_EXT)]
    if not img_files:
        raise FileNotFoundError(f"在{TRAIN_IMG_PATH}下未找到{IMG_EXT}格式的训练图像！")
    # 按21、22...40排序（DRIVE训练集命名：21_training.tif ~ 40_training.tif）
    img_files.sort(key=lambda x: int(x.split("_")[0]))
    
    for img_file in img_files:
        # 拼接图像和标注路径（严格匹配DRIVE命名规则：21_training.tif → 21_manual1.gif）
        img_name = os.path.splitext(img_file)[0]
        img_id = img_name.split("_")[0]  # 提取21、22等数字序号
        mask_file = f"{img_id}_manual1{MASK_EXT}"
        mask_full_path = os.path.join(TRAIN_MASK_PATH, mask_file)
        
        # 检查标注文件是否存在
        if not os.path.exists(mask_full_path):
            raise FileNotFoundError(f"图像{img_file}对应的标注文件不存在：{mask_full_path}")
        
        # 读取图像和标注（已做有效性检查，失败会直接报错）
        img_full_path = os.path.join(TRAIN_IMG_PATH, img_file)
        img = read_train_img(img_full_path)
        mask = read_train_mask(mask_full_path)
        
        # 确保图像和标注尺寸完全一致（DRIVE数据集标准要求）
        assert img.shape == mask.shape, \
            f"图像{img_file}和标注{mask_file}尺寸不一致！图像：{img.shape}，标注：{mask.shape}"
        h, w = img.shape
        print(f"✅ 处理{img_file}：尺寸{h}×{w}，开始裁剪补丁...")
        
        # 滑动窗口裁剪补丁（避免越界，步长24，补丁重叠50%）
        for i in range(0, h - PATCH_SIZE + 1, STRIDE):
            for j in range(0, w - PATCH_SIZE + 1, STRIDE):
                img_patch = img[i:i+PATCH_SIZE, j:j+PATCH_SIZE]  # 裁剪图像补丁
                mask_patch = mask[i:i+PATCH_SIZE, j:j+PATCH_SIZE]  # 裁剪标注补丁
                img_patches.append(img_patch)
                mask_patches.append(mask_patch)
    
    # 转为numpy数组（形状：[样本数, 48, 48]，符合模型训练要求）
    img_patches = np.array(img_patches, dtype=np.float32)
    mask_patches = np.array(mask_patches, dtype=np.float32)
    
    # 保存为NPY文件（到F:\毕业\DRIVE，覆盖原有文件）
    np.save(SAVE_IMG_PATCH, img_patches)
    np.save(SAVE_MASK_PATCH, mask_patches)
    
    # 打印生成完成信息（含关键参数，方便核对）
    print("="*60)
    print(f"🎉 DRIVE补丁生成完成！")
    print(f"📊 总生成补丁数：{img_patches.shape[0]}（图像/标注数量一致）")
    print(f"📊 补丁形状：{img_patches.shape}（[样本数, 48, 48]）")
    print(f"💾 图像补丁保存：{SAVE_IMG_PATCH}")
    print(f"💾 标注补丁保存：{SAVE_MASK_PATCH}")
    print(f"✅ 可直接用于SE-RetinaUnet模型训练！")
    print("="*60)

if __name__ == "__main__":
    # 运行前最终检查（确保原始目录/文件存在）
    if not os.path.exists(DRIVE_ROOT):
        raise FileNotFoundError(f"DRIVE根目录不存在：{DRIVE_ROOT}")
    if not os.path.exists(TRAIN_IMG_PATH):
        raise FileNotFoundError(f"训练图像目录不存在：{TRAIN_IMG_PATH}，请检查是否有training/images文件夹")
    if not os.path.exists(TRAIN_MASK_PATH):
        raise FileNotFoundError(f"标注目录不存在：{TRAIN_MASK_PATH}，请检查是否有training/1st_manual文件夹")
    if len(os.listdir(TRAIN_IMG_PATH)) == 0:
        raise FileNotFoundError(f"{TRAIN_IMG_PATH}下无{IMG_EXT}格式图像文件！")
    if len(os.listdir(TRAIN_MASK_PATH)) == 0:
        raise FileNotFoundError(f"{TRAIN_MASK_PATH}下无{MASK_EXT}格式标注文件！")
    
    # 开始裁剪补丁
    crop_patches()