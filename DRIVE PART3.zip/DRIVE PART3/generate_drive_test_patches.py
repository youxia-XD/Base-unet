import numpy as np
import os
from PIL import Image

# ===================== 配置（适配你的DRIVE目录，无需修改）=====================
DRIVE_ROOT = "F:\\毕业\\DRIVE"
TEST_IMG_PATH = os.path.join(DRIVE_ROOT, "testing", "images")    # 测试图像
TEST_MASK_PATH = os.path.join(DRIVE_ROOT, "testing", "1st_manual")# 测试金标准
TEST_FOV_PATH = os.path.join(DRIVE_ROOT, "testing", "mask")      # FOV掩码
PATCH_SIZE = 48  # 与训练一致
STRIDE = 24      # 与训练一致
IMG_EXT = ".tif"
MASK_EXT = ".gif"
FOV_EXT = ".gif"

# 保存路径（测试集补丁，供三个模型共用）
SAVE_TEST_IMG = os.path.join(DRIVE_ROOT, "patches_imgs_test.npy")
SAVE_TEST_MASK = os.path.join(DRIVE_ROOT, "patches_masks_test.npy")
SAVE_TEST_FOV = os.path.join(DRIVE_ROOT, "patches_fov_test.npy")
# 保存测试集原始尺寸（用于后续补丁拼接还原）
SAVE_TEST_SHAPE = os.path.join(DRIVE_ROOT, "test_img_shapes.npy")

# ===================== 工具函数 =====================
def read_img(img_path):
    """读取测试图像，转灰度+归一化"""
    img = Image.open(img_path).convert('L')
    img = np.array(img, dtype=np.float32) / 255.0
    return img

def read_gt(mask_path):
    """读取金标准，转二值图（0=背景，1=血管）"""
    gt = Image.open(mask_path).convert('L')
    gt = np.array(gt, dtype=np.float32)
    gt[gt == 255] = 1  # 金标准255代表血管
    return gt

def read_fov(fov_path):
    """读取FOV掩码（1=有效区域，0=背景，仅计算该区域指标）"""
    fov = Image.open(fov_path).convert('L')
    fov = np.array(fov, dtype=np.float32)
    fov[fov == 255] = 1  # FOV掩码255代表有效区域
    return fov

def crop_patches(img, gt, fov, patch_size=48, stride=24):
    """裁剪单张图像的补丁、金标准、FOV掩码"""
    img_patches, gt_patches, fov_patches = [], [], []
    h, w = img.shape
    for i in range(0, h - patch_size + 1, stride):
        for j in range(0, w - patch_size + 1, stride):
            img_p = img[i:i+patch_size, j:j+patch_size]
            gt_p = gt[i:i+patch_size, j:j+patch_size]
            fov_p = fov[i:i+patch_size, j:j+patch_size]
            img_patches.append(img_p)
            gt_patches.append(gt_p)
            fov_patches.append(fov_p)
    return np.array(img_patches), np.array(gt_patches), np.array(fov_patches)

# ===================== 核心预处理 =====================
def preprocess_test_set():
    print("🔍 开始DRIVE测试集预处理...")
    print(f"📂 测试图像路径：{TEST_IMG_PATH}")
    print(f"📂 金标准路径：{TEST_MASK_PATH}")
    print(f"📂 FOV掩码路径：{TEST_FOV_PATH}")

    all_img_patches = []
    all_gt_patches = []
    all_fov_patches = []
    test_img_shapes = []  # 保存每张测试图的原始尺寸 (h, w)

    # 获取测试图像文件，按序号排序（01~20）
    img_files = [f for f in os.listdir(TEST_IMG_PATH) if f.endswith(IMG_EXT)]
    img_files.sort(key=lambda x: int(x.split("_")[0]))

    for img_file in img_files:
        # 匹配金标准和FOV掩码（DRIVE命名规则：01_testing.tif → 01_manual1.gif → 01_test_mask.gif）
        img_id = img_file.split("_")[0]
        gt_file = f"{img_id}_manual1{MASK_EXT}"
        fov_file = f"{img_id}_test_mask{FOV_EXT}"

        img_path = os.path.join(TEST_IMG_PATH, img_file)
        gt_path = os.path.join(TEST_MASK_PATH, gt_file)
        fov_path = os.path.join(TEST_FOV_PATH, fov_file)

        # 读取数据
        img = read_img(img_path)
        gt = read_gt(gt_path)
        fov = read_fov(fov_path)
        test_img_shapes.append(img.shape)

        # 裁剪补丁
        img_p, gt_p, fov_p = crop_patches(img, gt, fov, PATCH_SIZE, STRIDE)
        all_img_patches.append(img_p)
        all_gt_patches.append(gt_p)
        all_fov_patches.append(fov_p)

        print(f"✅ 处理{img_file}：尺寸{img.shape}，生成{img_p.shape[0]}个补丁")

    # 合并所有测试图的补丁，转为NPY
    all_img_patches = np.concatenate(all_img_patches, axis=0)
    all_gt_patches = np.concatenate(all_gt_patches, axis=0)
    all_fov_patches = np.concatenate(all_fov_patches, axis=0)
    test_img_shapes = np.array(test_img_shapes, dtype=np.int32)

    # 保存文件
    np.save(SAVE_TEST_IMG, all_img_patches)
    np.save(SAVE_TEST_MASK, all_gt_patches)
    np.save(SAVE_TEST_FOV, all_fov_patches)
    np.save(SAVE_TEST_SHAPE, test_img_shapes)

    print("="*60)
    print(f"🎉 测试集预处理完成！生成4个核心文件：")
    print(f"📊 测试补丁总数：{all_img_patches.shape[0]}（48×48）")
    print(f"💾 图像补丁：{SAVE_TEST_IMG} ({all_img_patches.shape})")
    print(f"💾 金标准补丁：{SAVE_TEST_MASK} ({all_gt_patches.shape})")
    print(f"💾 FOV掩码补丁：{SAVE_TEST_FOV} ({all_fov_patches.shape})")
    print(f"💾 原始尺寸：{SAVE_TEST_SHAPE} ({test_img_shapes.shape})")
    print(f"✅ 可直接用于三个模型的测试推理！")
    print("="*60)

if __name__ == "__main__":
    # 检查目录
    for path in [TEST_IMG_PATH, TEST_MASK_PATH, TEST_FOV_PATH]:
        if not os.path.exists(path):
            raise FileNotFoundError(f"测试集目录不存在：{path}，请检查DRIVE结构！")
    preprocess_test_set()