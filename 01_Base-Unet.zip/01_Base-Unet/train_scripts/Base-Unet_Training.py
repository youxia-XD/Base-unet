# ==============================================
# Base-Unet 训练脚本：纯基础Unet结构（无SE、无Retina特有设计）
# 适配共用数据集：F:\毕业\DRIVE
# 训练参数与NoSE-RetinaUnet/SE-RetinaUnet完全一致，保证对比公平
# 所有文件保存在01_Base-Unet专属目录，与其他模型隔离
# ==============================================
import sys
import os

# 核心：切换到脚本所在目录，避免路径混乱
script_dir = os.path.dirname(os.path.abspath(__file__))
os.chdir(script_dir)
print(f"📌 已切换到Base-Unet脚本目录：{os.getcwd()}")

# 把项目根目录和lib文件夹加入Python模块搜索路径（通用配置）
sys.path.append(os.path.dirname(script_dir))  # 指向01_Base-Unet根目录
sys.path.append(os.path.join(os.path.dirname(script_dir), 'lib'))

import numpy as np
from keras.models import Model
from keras.layers import Input, concatenate, Conv2D, MaxPooling2D, UpSampling2D, Reshape, core, Dropout
from keras.optimizers import SGD
from keras.callbacks import ModelCheckpoint
from keras import backend as K

# 导入通用工具模块（从组二复制的lib，直接复用）
from lib.help_functions import *
from lib.extract_patches import get_data_training

# 确保实验文件夹存在，自动保存模型权重/结构
def create_exp_dir(exp_name):
    root_dir = os.path.dirname(script_dir)  # 指向01_Base-Unet根目录
    exp_path = os.path.join(root_dir, exp_name)
    if not os.path.exists(exp_path):
        os.makedirs(exp_path)
        print(f"✅ 创建Base-Unet实验文件夹：{exp_path}")
    return exp_path

# ==============================================
# 核心：纯基础Unet模型结构（无SE、无Retina特有设计，仅编码器+解码器+跳跃连接）
# 输入/输出格式与另外两组模型完全一致，保证后续预测/评估逻辑统一
# ==============================================
def get_unet(n_ch,patch_height,patch_width):
    inputs = Input(shape=(n_ch,patch_height,patch_width))  # channels_first，和另外两组一致
    # 编码器（下采样）：2层卷积+池化，共3级
    conv1 = Conv2D(32, (3, 3), activation='relu', padding='same', data_format='channels_first')(inputs)
    conv1 = Dropout(0.2)(conv1)
    conv1 = Conv2D(32, (3, 3), activation='relu', padding='same', data_format='channels_first')(conv1)
    pool1 = MaxPooling2D((2, 2), data_format='channels_first')(conv1)

    conv2 = Conv2D(64, (3, 3), activation='relu', padding='same', data_format='channels_first')(pool1)
    conv2 = Dropout(0.2)(conv2)
    conv2 = Conv2D(64, (3, 3), activation='relu', padding='same', data_format='channels_first')(conv2)
    pool2 = MaxPooling2D((2, 2), data_format='channels_first')(conv2)

    conv3 = Conv2D(128, (3, 3), activation='relu', padding='same', data_format='channels_first')(pool2)
    conv3 = Dropout(0.2)(conv3)
    conv3 = Conv2D(128, (3, 3), activation='relu', padding='same', data_format='channels_first')(conv3)

    # 解码器（上采样）：上采样+拼接+2层卷积，共2级
    up1 = UpSampling2D(size=(2, 2), data_format='channels_first')(conv3)
    up1 = concatenate([conv2, up1], axis=1)  # 跳跃连接，和另外两组一致
    conv4 = Conv2D(64, (3, 3), activation='relu', padding='same', data_format='channels_first')(up1)
    conv4 = Dropout(0.2)(conv4)
    conv4 = Conv2D(64, (3, 3), activation='relu', padding='same', data_format='channels_first')(conv4)

    up2 = UpSampling2D(size=(2, 2), data_format='channels_first')(conv4)
    up2 = concatenate([conv1, up2], axis=1)  # 跳跃连接
    conv5 = Conv2D(32, (3, 3), activation='relu', padding='same', data_format='channels_first')(up2)
    conv5 = Dropout(0.2)(conv5)
    conv5 = Conv2D(32, (3, 3), activation='relu', padding='same', data_format='channels_first')(conv5)

    # 输出层：和另外两组模型完全一致，保证预测/评估逻辑统一
    conv6 = Conv2D(2, (1, 1), activation='relu', padding='same', data_format='channels_first')(conv5)
    conv6 = core.Reshape((2, patch_height*patch_width))(conv6)
    conv6 = core.Permute((2, 1))(conv6)
    conv7 = core.Activation('softmax')(conv6)

    # 编译模型：优化器、损失函数、评估指标与另外两组完全一致
    model = Model(inputs=inputs, outputs=conv7)
    model.compile(optimizer='sgd', loss='categorical_crossentropy', metrics=['accuracy'])
    return model

# ==============================================
# 训练参数：与NoSE-RetinaUnet/SE-RetinaUnet完全一致（保证对比公平性）
# 仅修改实验名称，其余参数一字不改
# ==============================================
# 1. 共用数据集根路径（和组二/组三一致，指向F:\毕业\DRIVE）
path_data = "F:\\毕业\\DRIVE"
# 2. 实验名称（Base-Unet专属，保存权重/结构的文件夹）
name_experiment = "Base-Unet_Training"
exp_dir = create_exp_dir(name_experiment)
# 3. 训练参数（和组二/组三完全一致，无任何修改）
N_epochs = 100          # 训练轮数
batch_size = 32         # 批次大小
patch_height = 48       # 补丁高度
patch_width = 48        # 补丁宽度
N_subimgs = 10000       # 提取子图像数量
inside_FOV = True       # 仅选择FOV内的补丁
# 4. 数据集子路径（匹配DRIVE结构，无开头/，避免路径错误）
train_imgs_original = "training/images/"    # .tif训练图像
train_groundTruth = "training/1st_manual/" # .gif金标准标签

# ==============================================
# 路径拼接：用os.path.join自动补全反斜杠（彻底解决路径问题）
# 和组二最终修复版一致，无任何修改
# ==============================================
train_img_path = os.path.join(path_data, train_imgs_original)
train_gt_path = os.path.join(path_data, train_groundTruth)

# 打印所有参数，验证配置正确性
print("="*60)
print("✅ Base-Unet 所有配置已完成（与其他两组模型参数统一）：")
print(f"数据集根路径：{path_data}")
print(f"实验文件夹（权重保存）：{exp_dir}")
print(f"训练轮数：{N_epochs} | 批次大小：{batch_size}")
print(f"补丁尺寸：{patch_height}x{patch_width} | 子图像数量：{N_subimgs}")
print(f"✅ 实际训练图像路径：{train_img_path}")
print(f"✅ 实际金标准路径：{train_gt_path}")
print("="*60)

# ==============================================
# 加载数据+提取补丁（复用通用lib代码，无需修改）
# ==============================================
print("🚀 开始加载DRIVE训练集，提取48×48补丁...")
patches_imgs_train, patches_masks_train = get_data_training(
    DRIVE_train_imgs_original=train_img_path,
    DRIVE_train_groudTruth=train_gt_path,
    patch_height=patch_height,
    patch_width=patch_width,
    N_subimgs=N_subimgs,
    inside_FOV=inside_FOV
)
print("✅ 数据加载完成！训练补丁形状：", patches_imgs_train.shape)

# ==============================================
# 保存输入样本（验证数据加载正确，可选）
# ==============================================
N_sample = min(patches_imgs_train.shape[0], 40)
visualize(group_images(patches_imgs_train[0:N_sample,:,:,:],5), os.path.join(exp_dir, 'Base-Unet_sample_input_imgs'))
visualize(group_images(patches_masks_train[0:N_sample,:,:,:],5), os.path.join(exp_dir, 'Base-Unet_sample_input_masks'))
print("✅ 训练样本已保存，可在实验文件夹查看")

# ==============================================
# 构建模型+保存结构+开始训练（和组二/组三逻辑一致）
# ==============================================
# 构建基础Unet模型
n_ch = patches_imgs_train.shape[1]
model = get_unet(n_ch, patch_height, patch_width)
print("✅ Base-Unet模型构建完成，输出形状：", model.output_shape)

# 保存模型结构到专属文件夹
model_arch_path = os.path.join(exp_dir, f"{name_experiment}_architecture.json")
json_string = model.to_json()
with open(model_arch_path, 'w') as f:
    f.write(json_string)
print(f"✅ Base-Unet模型结构已保存到：{model_arch_path}")

# 保存最优模型权重（按验证损失筛选，和组二/组三一致）
checkpointer = ModelCheckpoint(
    filepath=os.path.join(exp_dir, f"{name_experiment}_best_weights.h5"),
    verbose=1,
    monitor='val_loss',
    mode='auto',
    save_best_only=True
)

# 转换mask格式（适配Unet训练，复用通用代码）
patches_masks_train = masks_Unet(patches_masks_train)

# 开始训练（全程在CPU运行，自动保存最优权重）
print("="*60)
print("🚀 开始训练Base-Unet模型（与其他两组参数完全一致）...")
print("="*60)
model.fit(
    patches_imgs_train,
    patches_masks_train,
    epochs=N_epochs,
    batch_size=batch_size,
    verbose=1,
    shuffle=True,
    validation_split=0.1,
    callbacks=[checkpointer]
)

# 保存最后一轮权重（备用）
last_weight_path = os.path.join(exp_dir, f"{name_experiment}_last_weights.h5")
model.save_weights(last_weight_path, overwrite=True)
print(f"✅ Base-Unet最后一轮权重已保存到：{last_weight_path}")

# 训练完成提示
print("="*60)
print("🎉 Base-Unet训练完成！所有文件均保存在专属目录：")
print(f"F:\毕业\01_Base-Unet\{name_experiment}")
print("✅ 权重/结构与其他两组模型完全隔离，可直接进行对比实验")
print("="*60)