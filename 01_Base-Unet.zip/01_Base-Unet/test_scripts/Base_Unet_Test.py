import numpy as np
import os
from PIL import Image
# 导入与训练时一致的模型构建函数（确保结构完全相同）
from keras.models import Model
from keras.layers import Input, Conv2D, MaxPooling2D, UpSampling2D, Dropout, concatenate, core

# ===================== 配置（仅改权重路径！）=====================
MODEL_NAME = "Base-Unet"  # 模型名称，用于结果保存
WEIGHT_PATH = "F:\\毕业\\01_Base-Unet\\Base-Unet_Training\\Base-Unet_Training_best_weights.h5"
DRIVE_ROOT = "F:\\毕业\\DRIVE"
# 测试集文件路径（第一步生成的，共用）
TEST_IMG_PATH = os.path.join(DRIVE_ROOT, "patches_imgs_test.npy")
TEST_GT_PATH = os.path.join(DRIVE_ROOT, "patches_masks_test.npy")
TEST_FOV_PATH = os.path.join(DRIVE_ROOT, "patches_fov_test.npy")
TEST_SHAPE_PATH = os.path.join(DRIVE_ROOT, "test_img_shapes.npy")
# 结果保存目录（自动创建）
SAVE_ROOT = os.path.join("F:\\毕业\\01_Base-Unet", "test_results")
os.makedirs(SAVE_ROOT, exist_ok=True)
SAVE_PRED_IMG = os.path.join(SAVE_ROOT, f"{MODEL_NAME}_pred_masks.npy")
SAVE_METRICS = os.path.join(SAVE_ROOT, f"{MODEL_NAME}_test_metrics.txt")
# 模型参数（与训练完全一致）
N_CH, PATCH_H, PATCH_W = 1, 48, 48
PATCH_SIZE = 48
STRIDE = 24
THRESHOLD = 0.5  # 概率二值化阈值（大于0.5为血管）

# ===================== 1. 构建基础Unet模型（与训练时完全一致！）=====================
def build_base_unet(n_ch, patch_height, patch_width):
    inputs = Input(shape=(n_ch, patch_height, patch_width))
    # 编码器
    conv1 = Conv2D(32, (3,3), activation='relu', padding='same', data_format='channels_first')(inputs)
    conv1 = Dropout(0.2)(conv1)
    conv1 = Conv2D(32, (3,3), activation='relu', padding='same', data_format='channels_first')(conv1)
    pool1 = MaxPooling2D((2,2), data_format='channels_first')(conv1)

    conv2 = Conv2D(64, (3,3), activation='relu', padding='same', data_format='channels_first')(pool1)
    conv2 = Dropout(0.2)(conv2)
    conv2 = Conv2D(64, (3,3), activation='relu', padding='same', data_format='channels_first')(conv2)
    pool2 = MaxPooling2D((2,2), data_format='channels_first')(conv2)

    conv3 = Conv2D(128, (3,3), activation='relu', padding='same', data_format='channels_first')(pool2)
    conv3 = Dropout(0.2)(conv3)
    conv3 = Conv2D(128, (3,3), activation='relu', padding='same', data_format='channels_first')(conv3)

    # 解码器
    up1 = UpSampling2D((2,2), data_format='channels_first')(conv3)
    up1 = concatenate([conv2, up1], axis=1)
    conv4 = Conv2D(64, (3,3), activation='relu', padding='same', data_format='channels_first')(up1)
    conv4 = Dropout(0.2)(conv4)
    conv4 = Conv2D(64, (3,3), activation='relu', padding='same', data_format='channels_first')(conv4)

    up2 = UpSampling2D((2,2), data_format='channels_first')(conv4)
    up2 = concatenate([conv1, up2], axis=1)
    conv5 = Conv2D(32, (3,3), activation='relu', padding='same', data_format='channels_first')(up2)
    conv5 = Dropout(0.2)(conv5)
    conv5 = Conv2D(32, (3,3), activation='relu', padding='same', data_format='channels_first')(conv5)

    # 输出层（与训练一致）
    conv6 = Conv2D(2, (1,1), activation='relu', padding='same', data_format='channels_first')(conv5)
    conv6 = core.Reshape((2, patch_height*patch_width))(conv6)
    conv6 = core.Permute((2, 1))(conv6)
    conv7 = core.Activation('softmax')(conv6)

    model = Model(inputs=inputs, outputs=conv7)
    model.compile(optimizer='sgd', loss='categorical_crossentropy', metrics=['accuracy'])
    return model

# ===================== 2. 量化指标计算函数（医学分割核心指标）=====================
def calculate_metrics(pred, gt, fov):
    """
    计算FOV内的核心指标：Accuracy、DSC（骰子系数）、IOU（交并比）、Sensitivity（灵敏度）、Specificity（特异度）
    pred：模型预测二值图（0/1）
    gt：金标准二值图（0/1）
    fov：FOV掩码（1=有效区域，0=背景）
    """
    # 仅保留FOV内的像素
    pred = pred[fov == 1]
    gt = gt[fov == 1]

    # 计算混淆矩阵
    tp = np.sum((pred == 1) & (gt == 1))  # 真阳性（血管预测为血管）
    tn = np.sum((pred == 0) & (gt == 0))  # 真阴性（背景预测为背景）
    fp = np.sum((pred == 1) & (gt == 0))  # 假阳性（背景预测为血管）
    fn = np.sum((pred == 0) & (gt == 1))  # 假阴性（血管预测为背景）

    # 计算指标（避免除0）
    accuracy = (tp + tn) / (tp + tn + fp + fn + 1e-8)
    dsc = 2 * tp / (2 * tp + fp + fn + 1e-8)  # DSC是医学分割最核心指标
    iou = tp / (tp + fp + fn + 1e-8)
    sensitivity = tp / (tp + fn + 1e-8)  # 漏检率的反面（越接近1，细血管分割越好）
    specificity = tn / (tn + fp + 1e-8)

    return {
        "Accuracy": round(accuracy, 4),
        "DSC": round(dsc, 4),
        "IOU": round(iou, 4),
        "Sensitivity": round(sensitivity, 4),
        "Specificity": round(specificity, 4),
        "TP": tp, "TN": tn, "FP": fp, "FN": fn
    }

# ===================== 3. 补丁拼接还原整图 =====================
def patches2img(patches, img_shapes, patch_size=48, stride=24):
    """将补丁推理结果还原为测试图原始尺寸"""
    imgs = []
    idx = 0
    for h, w in img_shapes:
        # 初始化空图和计数矩阵（处理重叠补丁）
        img = np.zeros((h, w), dtype=np.float32)
        count = np.zeros((h, w), dtype=np.float32)
        # 滑动窗口拼接
        for i in range(0, h - patch_size + 1, stride):
            for j in range(0, w - patch_size + 1, stride):
                img[i:i+patch_size, j:j+patch_size] += patches[idx]
                count[i:i+patch_size, j:j+patch_size] += 1
                idx += 1
        # 重叠区域取平均，避免拼接痕迹
        img = img / (count + 1e-8)
        imgs.append(img)
    return np.array(imgs)

# ===================== 4. 核心测试推理 =====================
def test_model():
    print(f"🚀 开始{MODEL_NAME}测试集推理...")
    print(f"📌 加载最优权重：{WEIGHT_PATH}")
    print(f"📌 测试集补丁数：{np.load(TEST_IMG_PATH).shape[0]}")

    # 步骤1：加载测试数据
    test_imgs = np.load(TEST_IMG_PATH)  # (N,48,48)
    test_gt = np.load(TEST_GT_PATH)    # (N,48,48)
    test_fov = np.load(TEST_FOV_PATH)  # (N,48,48)
    test_shapes = np.load(TEST_SHAPE_PATH)  # (20,2) 每张图的(h,w)

    # 步骤2：适配模型输入（3维→4维，channels_first：(N,1,48,48)）
    test_imgs = np.expand_dims(test_imgs, axis=1)

    # 步骤3：构建模型+加载权重
    model = build_base_unet(N_CH, PATCH_H, PATCH_W)
    if os.path.exists(WEIGHT_PATH):
        model.load_weights(WEIGHT_PATH)
        print("✅ 模型权重加载成功！")
    else:
        raise FileNotFoundError(f"权重文件不存在：{WEIGHT_PATH}")

    # 步骤4：模型推理（输出softmax概率，shape=(N,2304,2)）
    pred_probs = model.predict(test_imgs, batch_size=32, verbose=1)
    # 提取血管类概率（第2列），还原为补丁形状(N,48,48)
    pred_vessel = pred_probs[:, :, 1].reshape(-1, PATCH_SIZE, PATCH_SIZE)
    # 二值化（大于阈值为血管）
    pred_binary = (pred_vessel > THRESHOLD).astype(np.float32)

    # 步骤5：拼接还原整图（20张，每张584×565）
    pred_imgs = patches2img(pred_binary, test_shapes, PATCH_SIZE, STRIDE)
    gt_imgs = patches2img(test_gt, test_shapes, PATCH_SIZE, STRIDE)
    fov_imgs = patches2img(test_fov, test_shapes, PATCH_SIZE, STRIDE)
    # 保存预测结果
    np.save(SAVE_PRED_IMG, pred_imgs)
    print(f"✅ 预测结果保存：{SAVE_PRED_IMG} ({pred_imgs.shape})")

    # 步骤6：计算整体指标（20张测试图平均）
    all_metrics = []
    for i in range(len(pred_imgs)):
        metrics = calculate_metrics(pred_imgs[i], gt_imgs[i], fov_imgs[i])
        all_metrics.append(metrics)
        print(f"📊 测试图{i+1}指标：DSC={metrics['DSC']}, IOU={metrics['IOU']}, Acc={metrics['Accuracy']}")

    # 计算平均指标
    avg_metrics = {
        "Average_Accuracy": round(np.mean([m['Accuracy'] for m in all_metrics]), 4),
        "Average_DSC": round(np.mean([m['DSC'] for m in all_metrics]), 4),
        "Average_IOU": round(np.mean([m['IOU'] for m in all_metrics]), 4),
        "Average_Sensitivity": round(np.mean([m['Sensitivity'] for m in all_metrics]), 4),
        "Average_Specificity": round(np.mean([m['Specificity'] for m in all_metrics]), 4)
    }

    # 步骤7：保存指标到文件
    with open(SAVE_METRICS, "w", encoding="utf-8") as f:
        f.write(f"{MODEL_NAME} DRIVE测试集量化指标（FOV内，20张平均）\n")
        f.write("="*50 + "\n")
        for k, v in avg_metrics.items():
            f.write(f"{k}: {v}\n")
        f.write("="*50 + "\n")
        f.write("单张图像详细指标：\n")
        for i, m in enumerate(all_metrics):
            f.write(f"测试图{i+1}: {m}\n")

    # 打印最终结果
    print("="*60)
    print(f"🎉 {MODEL_NAME}测试完成！平均核心指标：")
    print(f"📊 准确率（Accuracy）：{avg_metrics['Average_Accuracy']}")
    print(f"📊 骰子系数（DSC）：{avg_metrics['Average_DSC']} → 核心指标！")
    print(f"📊 交并比（IOU）：{avg_metrics['Average_IOU']}")
    print(f"📊 灵敏度（Sensitivity）：{avg_metrics['Average_Sensitivity']} → 细血管分割能力！")
    print(f"📊 特异度（Specificity）：{avg_metrics['Average_Specificity']}")
    print(f"💾 指标保存到：{SAVE_METRICS}")
    print("="*60)

if __name__ == "__main__":
    test_model()