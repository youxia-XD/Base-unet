# 03_SE-RetinaUnet/train_scripts/config.py
import os
# ********** 只改这1个路径：你的DRIVE数据集根路径（比如F:/毕业/Retina-Unet-master/DRIVE）
DRIVE_ROOT = "F:/毕业/Retina-Unet-master/DRIVE"
DRIVE_TEST_PATH = os.path.join(DRIVE_ROOT, "test")
# 模型权重路径（本文件夹内，无需修改）
WEIGHT_PATH = os.path.join(os.path.dirname(os.getcwd()), "model_weights", "Retina_Unet_SE_best_weights.h5")
# 实验结果保存路径（本文件夹内，无需修改）
RESULT_PATH = os.path.join(os.path.dirname(os.getcwd()), "experiment_results")
os.makedirs(RESULT_PATH, exist_ok=True)
os.makedirs(os.path.join(RESULT_PATH, "pred_masks"), exist_ok=True)
os.makedirs(os.path.join(RESULT_PATH, "metrics"), exist_ok=True)
os.makedirs(os.path.join(RESULT_PATH, "visualization"), exist_ok=True)