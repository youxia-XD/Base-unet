# ==============================================
# Attention-Unet训练代码（适配RetinaUnet路径逻辑）
# 1. 全F盘运行，无C盘依赖
# 2. 复用RetinaUnet的补丁提取/路径拼接/参数体系
# 3. 保留Attention机制核心逻辑，适配channels_first格式
# 4. 所有文件保存在F盘Retina-Unet-master目录
# ==============================================
import sys
import os
import numpy as np

# 核心：切换到脚本所在的F盘目录（彻底避免C盘存储）
script_dir = os.path.dirname(os.path.abspath(__file__))
os.chdir(script_dir)
print(f"📌 已切换到脚本目录：{os.getcwd()}")

# ========== 修复lib模块路径（关键） ==========
# 项目根目录：F:\毕业\03_SE-RetinaUnet（train_scripts的上级目录）
project_root = os.path.dirname(script_dir)
# 把项目根目录和真实lib目录加入Python搜索路径
sys.path.append(project_root)
sys.path.append(os.path.join(project_root, 'lib'))

# 打印路径，验证是否正确指向F盘lib
lib_path = os.path.join(project_root, 'lib')
print(f"✅ 项目根目录：{project_root}")
print(f"✅ lib目录路径：{lib_path}")
print(f"✅ lib目录是否存在：{os.path.exists(lib_path)}")  # 输出True则正确

# ========== 适配RetinaUnet的导入逻辑 ==========
from keras.models import Model
from keras.layers import Input, concatenate, Conv2D, MaxPooling2D, UpSampling2D, Reshape, core, Dropout
from keras.layers import BatchNormalization, Activation, Conv2DTranspose, Lambda, multiply, add
from keras.optimizers import Adam, SGD
from keras.callbacks import ModelCheckpoint, LearningRateScheduler, ReduceLROnPlateau
from keras.regularizers import l2
from keras import backend as K

# 导入RetinaUnet共用的自定义模块（现在能正确找到）
from lib.help_functions import *
from lib.extract_patches import get_data_training

# ... 其余代码不变 ...

# 确保实验文件夹存在，避免保存文件时报错（复用RetinaUnet函数）
def create_exp_dir(exp_name):
    exp_path = os.path.join(script_dir, exp_name)
    if not os.path.exists(exp_path):
        os.makedirs(exp_path)
        print(f"✅ 创建实验文件夹：{exp_path}")
    return exp_path

# ========== Attention模块（适配channels_first格式） ==========
def attention_block(x, gating, inter_shape, data_format='channels_first'):
    """
    软注意力模块：适配channels_first数据格式（和RetinaUnet一致）
    x: 编码器特征图
    gating: 解码器特征图（门控信号）
    inter_shape: 中间通道数
    """
    # 获取特征图形状（channels_first）
    shape_x = K.int_shape(x)  # (None, ch, h, w)
    shape_g = K.int_shape(gating)
    
    # 下采样x到gating尺寸（channels_first）
    theta_x = Conv2D(inter_shape, (2, 2), strides=(2, 2), 
                     kernel_initializer='he_normal', padding='same',
                     data_format=data_format)(x) 
    shape_theta_x = K.int_shape(theta_x)
    
    # 调整gating通道数
    phi_g = Conv2D(inter_shape, (1, 1), kernel_initializer='he_normal', 
                   padding='same', data_format=data_format)(gating)
    
    # 上采样gating（匹配theta_x尺寸）
    stride_val = shape_theta_x[2] // shape_g[2]  # height维度下采样倍数
    upsample_g = Conv2DTranspose(inter_shape, (3, 3), 
                                 strides=stride_val,
                                 kernel_initializer='he_normal', padding='same',
                                 data_format=data_format)(phi_g)
    
    # 注意力权重计算
    concat_xg = add([upsample_g, theta_x])
    act_xg = Activation('relu')(concat_xg)
    psi = Conv2D(1, (1, 1), kernel_initializer='he_normal', 
                 padding='same', data_format=data_format)(act_xg)
    sigmoid_xg = Activation('sigmoid')(psi)  # 0-1注意力权重
    
    # 上采样权重到原x尺寸
    shape_sigmoid = K.int_shape(sigmoid_xg)
    upsample_psi = UpSampling2D(size=(shape_x[2] // shape_sigmoid[2], shape_x[3] // shape_sigmoid[3]),
                                data_format=data_format)(sigmoid_xg) 
    # 复制权重到所有通道（channels_first）
    if data_format == 'channels_first':
        upsample_psi = Lambda(lambda x: K.repeat_elements(x, shape_x[1], axis=1))(upsample_psi)
    else:
        upsample_psi = Lambda(lambda x: K.repeat_elements(x, shape_x[3], axis=-1))(upsample_psi)
    
    # 特征加权
    y = multiply([upsample_psi, x])
    # 恢复通道数
    result = Conv2D(shape_x[1], (1, 1), kernel_initializer='he_normal', 
                    padding='same', data_format=data_format)(y)
    attenblock = BatchNormalization(axis=1 if data_format=='channels_first' else -1)(result)
    return attenblock

def gatingsignal(input, out_size, batchnorm=True, data_format='channels_first'):
    """门控信号：压缩通道数，引导注意力聚焦"""
    x = Conv2D(out_size, (1, 1), padding='same', kernel_initializer='he_normal',
               data_format=data_format)(input)
    if batchnorm:
        x = BatchNormalization(axis=1 if data_format=='channels_first' else -1)(x)
    x = Activation('relu')(x)
    return x

# ========== Attention-Unet模型（适配RetinaUnet结构） ==========
def get_attention_unet(n_ch, patch_height, patch_width):
    """
    基于RetinaUnet重构的Attention-Unet
    - 复用channels_first格式
    - 保持补丁尺寸(48x48)和通道数兼容
    - 保留原Unet的核心结构，增加Attention模块
    """
    data_format = 'channels_first'
    inputs = Input(shape=(n_ch, patch_height, patch_width))
    
    # ===================== 编码器（和RetinaUnet一致）=====================
    conv1 = Conv2D(32, (3, 3), activation='relu', padding='same',
                   data_format=data_format, kernel_regularizer=l2(1e-5))(inputs)
    conv1 = Dropout(0.2)(conv1)
    conv1 = Conv2D(32, (3, 3), activation='relu', padding='same',
                   data_format=data_format, kernel_regularizer=l2(1e-5))(conv1)
    pool1 = MaxPooling2D((2, 2), data_format=data_format)(conv1)  # 24x24
    
    conv2 = Conv2D(64, (3, 3), activation='relu', padding='same',
                   data_format=data_format, kernel_regularizer=l2(1e-5))(pool1)
    conv2 = Dropout(0.2)(conv2)
    conv2 = Conv2D(64, (3, 3), activation='relu', padding='same',
                   data_format=data_format, kernel_regularizer=l2(1e-5))(conv2)
    pool2 = MaxPooling2D((2, 2), data_format=data_format)(conv2)  # 12x12
    
    # 瓶颈层（增加Attention门控）
    conv3 = Conv2D(128, (3, 3), activation='relu', padding='same',
                   data_format=data_format, kernel_regularizer=l2(1e-5))(pool2)
    conv3 = Dropout(0.2)(conv3)
    conv3 = Conv2D(128, (3, 3), activation='relu', padding='same',
                   data_format=data_format, kernel_regularizer=l2(1e-5))(conv3)  # 12x12
    
    # ===================== 解码器（增加Attention模块）=====================
    # 上采样+Attention（conv3 -> conv2）
    gating3 = gatingsignal(conv3, 64, data_format=data_format)
    att3 = attention_block(conv2, gating3, 64, data_format=data_format)
    up1 = UpSampling2D(size=(2, 2), data_format=data_format)(conv3)  # 24x24
    up1 = concatenate([att3, up1], axis=1)  # channels_first，axis=1
    
    conv4 = Conv2D(64, (3, 3), activation='relu', padding='same',
                   data_format=data_format, kernel_regularizer=l2(1e-5))(up1)
    conv4 = Dropout(0.2)(conv4)
    conv4 = Conv2D(64, (3, 3), activation='relu', padding='same',
                   data_format=data_format, kernel_regularizer=l2(1e-5))(conv4)  # 24x24
    
    # 上采样+Attention（conv4 -> conv1）
    gating4 = gatingsignal(conv4, 32, data_format=data_format)
    att4 = attention_block(conv1, gating4, 32, data_format=data_format)
    up2 = UpSampling2D(size=(2, 2), data_format=data_format)(conv4)  # 48x48
    up2 = concatenate([att4, up2], axis=1)
    
    conv5 = Conv2D(32, (3, 3), activation='relu', padding='same',
                   data_format=data_format, kernel_regularizer=l2(1e-5))(up2)
    conv5 = Dropout(0.2)(conv5)
    conv5 = Conv2D(32, (3, 3), activation='relu', padding='same',
                   data_format=data_format, kernel_regularizer=l2(1e-5))(conv5)  # 48x48
    
    # ===================== 输出层（和RetinaUnet完全一致）=====================
    conv6 = Conv2D(2, (1, 1), activation='relu', padding='same',
                   data_format=data_format)(conv5)
    conv6 = core.Reshape((2, patch_height*patch_width))(conv6)
    conv6 = core.Permute((2, 1))(conv6)
    conv7 = core.Activation('softmax')(conv6)

    # 编译模型（和RetinaUnet一致的优化器/损失函数）
    model = Model(inputs=inputs, outputs=conv7)
    model.compile(optimizer='sgd', loss='categorical_crossentropy', metrics=['accuracy'])
    return model

# ========= 硬编码参数（和RetinaUnet完全一致，指向F盘） =========
# 1. 数据集根路径：复用你的DRIVE路径
path_data = "F:\\毕业\\DRIVE"

# 2. 实验名称（独立文件夹，避免和RetinaUnet冲突）
name_experiment = "Attention_Unet_Training"
exp_dir = create_exp_dir(name_experiment)

# 3. 训练参数（和RetinaUnet完全对齐）
N_epochs = 100          # 训练轮数（统一100轮）
batch_size = 32         # 批次大小
patch_height = 48       # 补丁高度
patch_width = 48        # 补丁宽度
N_subimgs = 10000       # 提取的子图像数量
inside_FOV = True       # 只选择FOV内的补丁

# 4. 数据集子路径（复用RetinaUnet的路径层级）
train_imgs_original = "training/images/"
train_groundTruth = "training/1st_manual/"

# 【关键】用os.path.join拼接路径，适配Windows反斜杠
train_img_path = os.path.join(path_data, train_imgs_original)
train_gt_path = os.path.join(path_data, train_groundTruth)

# 打印所有参数，确认路径正确
print("="*50)
print("✅ Attention-Unet训练参数已设置：")
print(f"数据集根路径：{path_data}")
print(f"实验文件夹：{exp_dir}")
print(f"训练轮数：{N_epochs} | 批次大小：{batch_size}")
print(f"补丁尺寸：{patch_height}x{patch_width} | 子图像数量：{N_subimgs}")
print(f"✅ 训练图像路径：{train_img_path}")
print(f"✅ 金标准路径：{train_gt_path}")
print("="*50)

# ============ 加载数据并提取补丁（复用RetinaUnet逻辑） ============
print("📥 开始加载DRIVE数据并提取补丁...")
patches_imgs_train, patches_masks_train = get_data_training(
    DRIVE_train_imgs_original=train_img_path,
    DRIVE_train_groudTruth=train_gt_path,
    patch_height=patch_height,
    patch_width=patch_width,
    N_subimgs=N_subimgs,
    inside_FOV=inside_FOV
)
print(f"✅ 数据加载完成：训练补丁数={patches_imgs_train.shape[0]}")

# ========= 保存输入样本（验证数据加载正确） ==========
N_sample = min(patches_imgs_train.shape[0],40)
visualize(group_images(patches_imgs_train[0:N_sample,:,:,:],5),
          os.path.join(exp_dir,'sample_input_imgs'))
visualize(group_images(patches_masks_train[0:N_sample,:,:,:],5),
          os.path.join(exp_dir,'sample_input_masks'))
print("✅ 输入样本已保存到实验文件夹")

# =========== 构建Attention-Unet模型 =====
n_ch = patches_imgs_train.shape[1]
model = get_attention_unet(n_ch, patch_height, patch_width)
print("✅ Attention-Unet模型构建完成，输出形状：", model.output_shape)

# 保存模型结构到F盘
json_string = model.to_json()
model_arch_path = os.path.join(exp_dir, f"{name_experiment}_architecture.json")
with open(model_arch_path, 'w') as f:
    f.write(json_string)
print(f"✅ 模型结构已保存到：{model_arch_path}")

# ============ 训练模型（和RetinaUnet一致的流程） ==================================
# 保存最优模型权重（F盘独立目录）
checkpointer = ModelCheckpoint(
    filepath=os.path.join(exp_dir, f"{name_experiment}_best_weights.h5"), 
    verbose=1, 
    monitor='val_loss', 
    mode='auto', 
    save_best_only=True
)

# 转换mask格式（复用RetinaUnet的格式转换逻辑）
patches_masks_train = masks_Unet(patches_masks_train)  

# 开始训练（100轮，和RetinaUnet公平对比）
print("="*50)
print("🚀 开始训练Attention-Unet（全程在F盘运行）...")
print("="*50)
model.fit(
    patches_imgs_train, 
    patches_masks_train, 
    epochs=N_epochs, 
    batch_size=batch_size, 
    verbose=1, 
    shuffle=True, 
    validation_split=0.1,  # 10%验证集
    callbacks=[checkpointer]
)

# ========== 保存最后一轮模型权重 ===================
last_weight_path = os.path.join(exp_dir, f"{name_experiment}_last_weights.h5")
model.save_weights(last_weight_path, overwrite=True)
print(f"✅ 最后一轮权重已保存到：{last_weight_path}")

# 训练完成提示
print("="*50)
print("🎉 Attention-Unet 100轮训练完成！")
print(f"📁 所有文件保存路径：{exp_dir}")
print("✅ 最优权重：{name_experiment}_best_weights.h5")
print("✅ 最后权重：{name_experiment}_last_weights.h5")
print("="*50)