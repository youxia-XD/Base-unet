import os
import numpy as np
import cv2
from PIL import Image  # 新增：适配GIF加载
from tqdm import tqdm

# ===================== 仅需确认这1行！你的DRIVE原始数据集根路径 =====================
DRIVE_ROOT = "F:/毕业/Retina-Unet-master/DRIVE"
# ==================================================================================

PATCH_SIZE = 48  # 补丁尺寸，和模型一致
STRIDE = 24      # 切割步长，重叠一半
NUM_CHANNELS = 1 # 单通道

def load_image(img_path, is_mask=False):
    """
    加载图像/标签：TIFF（PIL）+ GIF（PIL），彻底解决格式兼容问题
    :param is_mask: True=加载GIF标签，False=加载TIFF图像
    """
    try:
        with Image.open(img_path) as im:
            # 无论TIFF/GIF，都用PIL加载，转灰度图
            img = np.array(im.convert('L'))  # convert('L')=转8位灰度图，适配所有格式
    except Exception as e:
        raise FileNotFoundError(f"文件加载失败！路径：{img_path}，错误：{e}（请检查文件是否存在/未损坏）")
    
    # 归一化：统一转0-1浮点数
    img = img / 255.0
    # 标签二值化（血管=1，背景=0）
    if is_mask:
        img = np.where(img > 0.5, 1, 0)  # 过滤灰度值，纯二值化
    return img.astype(np.float32)
    
def cut_patches(img, mask, patch_size, stride):
    """切割补丁，过滤全黑无效补丁"""
    img_patches = []
    mask_patches = []
    h, w = img.shape
    # 滑动窗口切割（确保不越界）
    for y in range(0, h - patch_size + 1, stride):
        for x in range(0, w - patch_size + 1, stride):
            img_patch = img[y:y+patch_size, x:x+patch_size]
            mask_patch = mask[y:y+patch_size, x:x+patch_size]
            # 过滤有效补丁：图像非全黑（有效像素占比>10%）
            if np.mean(img_patch) > 0.1:
                img_patches.append(img_patch)
                mask_patches.append(mask_patch)
    return img_patches, mask_patches

def main():
    print(f"🔧 DRIVE预处理启动（适配GIF标签+TIFF图像）")
    print(f"📌 根路径：{DRIVE_ROOT} | 补丁尺寸：{PATCH_SIZE}×{PATCH_SIZE}")
    # 严格定义数据集路径（强制校验）
    train_img_dir = os.path.join(DRIVE_ROOT, "training", "images")    # TIFF图像
    train_mask_dir = os.path.join(DRIVE_ROOT, "training", "1st_manual")# GIF标签
    # 校验文件夹是否存在
    for dir_path in [train_img_dir, train_mask_dir]:
        if not os.path.exists(dir_path):
            raise NotADirectoryError(f"文件夹不存在！{dir_path}，请检查DRIVE结构")

    # 🔴 核心适配：文件匹配规则（图像=TIFF，标签=GIF）
    img_files = [f for f in os.listdir(train_img_dir) if f.endswith(".tif") and "_training" in f]
    mask_files = [f for f in os.listdir(train_mask_dir) if f.endswith(".gif") and "_manual1" in f]
    # 按数字排序（确保1_image.tif ↔ 1_manual1.gif 一一匹配）
    img_files.sort(key=lambda x: int(x.split("_")[0]))
    mask_files.sort(key=lambda x: int(x.split("_")[0]))

    print(f"🔍 找到训练图像（TIFF）：{len(img_files)}张")
    print(f"🔍 找到训练标签（GIF）：{len(mask_files)}张")
    # 基础校验
    if len(img_files) == 0 or len(mask_files) == 0:
        raise ValueError("未找到有效文件！请检查：images=TIFF/_image，1st_manual=GIF/_manual1")
    if len(img_files) != len(mask_files):
        raise ValueError(f"图像和标签数量不匹配！{len(img_files)}≠{len(mask_files)}")

    all_img_patches = []
    all_mask_patches = []
    # 遍历切割补丁（带进度条）
    for idx, (img_name, mask_name) in enumerate(tqdm(zip(img_files, mask_files), total=len(img_files), desc="切割补丁中")):
        img_path = os.path.join(train_img_dir, img_name)
        mask_path = os.path.join(train_mask_dir, mask_name)
        # 加载图像/标签（自动适配格式）
        img = load_image(img_path, is_mask=False)
        mask = load_image(mask_path, is_mask=True)
        # 切割补丁
        img_patches, mask_patches = cut_patches(img, mask, PATCH_SIZE, STRIDE)
        all_img_patches.extend(img_patches)
        all_mask_patches.extend(mask_patches)

    # 空样本校验（核心！避免生成0样本文件）
    if len(all_img_patches) == 0:
        raise ValueError("未切割出任何有效补丁！请检查：1.图像/标签是否为空白 2.文件名是否匹配")
    print(f"\n✅ 补丁切割完成 | 总有效训练样本数：{len(all_img_patches)}")

    # 转换为模型所需格式 (N,C,H,W) + One-Hot编码（适配channels_first）
    img_array = np.array(all_img_patches, dtype=np.float32)[:, np.newaxis, :, :]  # (N,H,W)→(N,1,H,W)
    mask_array = np.array(all_mask_patches, dtype=np.float32)
    # 标签One-Hot编码：(N,H,W)→(N,2,H,W)（背景=通道0，血管=通道1）
    mask_array = np.stack([1 - mask_array, mask_array], axis=1)

    # 保存.npy文件（覆盖原有0样本文件，直接用于训练）
    save_img_path = os.path.join(DRIVE_ROOT, "patches_imgs_train.npy")
    save_mask_path = os.path.join(DRIVE_ROOT, "patches_masks_train.npy")
    np.save(save_img_path, img_array)
    np.save(save_mask_path, mask_array)

    # 打印最终结果
    print(f"🎉 预处理成功！生成2个训练文件（直接用于retinaNN_training.py）")
    print(f"📁 图像补丁：{save_img_path} | 形状：{img_array.shape} (N,C,H,W)")
    print(f"📁 标签补丁：{save_mask_path} | 形状：{mask_array.shape} (N,2,H,W)")
    print(f"💡 样本数：{img_array.shape[0]} | 适配你的Retina-Unet+SE模型")

if __name__ == "__main__":
    # 自动安装缺失依赖（cv2/PIL/tqdm）
    required_pkgs = {"cv2": "opencv-python", "PIL": "Pillow", "tqdm": "tqdm"}
    for pkg, install_name in required_pkgs.items():
        try:
            __import__(pkg)
        except ImportError:
            print(f"📦 自动安装依赖：{install_name}")
            os.system(f"pip install {install_name} -q")
    # 启动预处理
    main()